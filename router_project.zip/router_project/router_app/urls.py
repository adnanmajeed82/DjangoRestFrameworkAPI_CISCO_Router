
# router_app/urls.py
from django.urls import path
from .views import CiscoRouterListCreateView, CiscoRouterRetrieveUpdateDestroyView

urlpatterns = [
    path('routers/', CiscoRouterListCreateView.as_view(), name='router-list-create'),
    path('routers/<int:pk>/', CiscoRouterRetrieveUpdateDestroyView.as_view(), name='router-retrieve-update-destroy'),
]
