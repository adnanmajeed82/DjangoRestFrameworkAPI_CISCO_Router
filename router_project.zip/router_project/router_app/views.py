# router_app/views.py
from rest_framework import generics
from .models import CiscoRouter
from .serializers import CiscoRouterSerializer

class CiscoRouterListCreateView(generics.ListCreateAPIView):
    queryset = CiscoRouter.objects.all()
    serializer_class = CiscoRouterSerializer

class CiscoRouterRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CiscoRouter.objects.all()
    serializer_class = CiscoRouterSerializer
