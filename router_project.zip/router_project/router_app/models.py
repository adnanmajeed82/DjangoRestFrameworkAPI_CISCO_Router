# router_app/models.py
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
import requests 

class CiscoRouter(models.Model):
    hostname = models.CharField(max_length=100)
    ip_address = models.GenericIPAddressField()
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    def __str__(self):
        return self.hostname
@receiver(post_save, sender=CiscoRouter)
def synchronize_router(sender, instance, **kwargs):
    """
    Signal handler to synchronize with the Cisco router.
    Replace the print statements with actual synchronization code.
    """
    if kwargs.get('created', False):
        print(f"Router '{instance.hostname}' created. Initiating synchronization...")
        synchronize_with_router(instance)
    else:
        print(f"Router '{instance.hostname}' updated. Initiating synchronization...")
        synchronize_with_router(instance)

def synchronize_with_router(router_instance):
    """
    Replace this function with the actual synchronization code.
    This is just a placeholder to give you an idea.
    """
    try:
        # Example: Make an API call to the Cisco router
        api_url = f"http://{router_instance.ip_address}/api/synchronize/"
        response = requests.post(api_url, auth=(router_instance.username, router_instance.password))

        if response.status_code == 200:
            print(f"Synchronization with '{router_instance.hostname}' successful.")
        else:
            print(f"Synchronization with '{router_instance.hostname}' failed. Status code: {response.status_code}")
    except Exception as e:
        print(f"Error during synchronization with '{router_instance.hostname}': {e}")